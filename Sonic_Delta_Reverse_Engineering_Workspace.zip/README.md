# Sonic Multi-Bank Workspace
Use `make` to compile.
