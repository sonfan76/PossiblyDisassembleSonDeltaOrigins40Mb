# Sega Genesis / M68K Dynamic Analysis, Ghidra Overlay & vasm Rebuild Toolkit

This archive contains the complete Motorola 68000 disassembly, dynamic bank-switch tracing, Ghidra overlay mapping, and `vasm` rebuild pipeline discussed in our session.

## Included Files

### 1. Dynamic Tracing & Mapper Probing
* `probe_mapper.py` — Scans a 40Mbit (5MB) Genesis binary for hardware references to standard SSF2 (`$A130F1`–`$A130FF`) or custom (`$220000`–`$22000F`) bank-switching registers and generates `blastem_probe.txt`.
* `trace_banks.txt` — Ready-to-use BlastEm CLI debugger (`blastem -d`) watchpoint script for trapping SSF2 and `$220000` bank swaps.
* `collect_trace.py` — Automated BlastEm trace collector that launches `blastem -d`, captures register dumps and disassembled instructions at every bank switch, resolves immediate/register bank indices, and saves `resolved_switches.json`.
* `mame_mesen_watchpoints.lua` — Alternative Lua dynamic bank-switch logger for MAME or Mesen emulator environments.

### 2. Ghidra Headless Overlay & Byte-Accurate Exporter
* `ghidra_auto_bank.py` — Ghidra Jython script that slices banks 8+ (`>= 0x400000`) into separate 512KB (`0x80000`) Overlay Blocks, annotates caller PCs with cross-bank references from `resolved_switches.json`, and exports byte-accurate `.asm` files (preserving both decoded instructions and raw `dc.b` data rows).
* `run_pipeline.sh` — One-command Bash runner executing `collect_trace.py` followed by Ghidra `analyzeHeadless`.

### 3. vasm Syntax Normalization, Rebuild & Testing
* `format_for_vasm.py` — Two-pass Motorola 68000 syntax normalizer and symbolic label resolver (`loc_XXXXXX` / `dat_XXXXXX`) for `vasmm68k_mot`.
* `Makefile` — Builds each 512KB `.asm` bank independently with `vasmm68k_mot`, pads each slice to exact `524,288` bytes, stitches the 40Mbit binary, fixes the Genesis header checksum at `$018E`, and compares against the original ROM.
* `test_pipeline.py` — Self-contained dry-run verification test for the symbolic formatter and `vasm` assembly step.

### 4. Standalone M68K Genesis Hardware Subroutines
* `genesis_subroutines.asm` — Modular Motorola 68000 assembly routines (`Initialize_VDP`, `Clear_VRAM`, `Print_ASCII_String`, and `Poll_Controller_1`) plus the `split_rom_banks.sh` binary slicing utility.

## Quick Start

```bash
chmod +x run_pipeline.sh split_rom_banks.sh probe_mapper.py collect_trace.py format_for_vasm.py test_pipeline.py

# 1. Run dry-run formatter & vasm test
python3 test_pipeline.py

# 2. Probe target 40Mbit ROM for active mapper registers
python3 probe_mapper.py sonic_delta_origins.bin

# 3. Capture live bank switches in BlastEm
python3 collect_trace.py sonic_delta_origins.bin

# 4. Run Ghidra headless overlay mapping & export vasm .asm files
./run_pipeline.sh

# 5. Format, compile with vasmm68k_mot, stitch 40Mbit ROM, and verify
cd ~/sonic_delta_vasm_export && cp /path/to/Makefile /path/to/format_for_vasm.py .
make && make verify
```
