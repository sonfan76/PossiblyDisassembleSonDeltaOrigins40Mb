; =============================================================================
; STANDALONE SEGA GENESIS (MOTOROLA 68000) HARDWARE SUBROUTINES
; Assembler Target: vasmm68k_mot -Fbin -m68000
; =============================================================================

; -----------------------------------------------------------------------------
; 1. VDP CONTROL REGISTER INITIALIZATION
; -----------------------------------------------------------------------------
Initialize_VDP:
    lea     VDP_Register_Data, a0   ; Point a0 to configuration data array
    move.w  #23, d0                 ; Loop counter: 24 registers total (0 to 23)
    move.w  #$8000, d1              ; Command register base bit parameter

.VDP_Load_Loop:
    move.b  (a0)+, d1               ; Fetch byte value into lower d1
    move.w  d1, $00C00004           ; Write word command to VDP Control Port
    add.w   #$0100, d1              ; Increment register index in upper byte
    dbra    d0, .VDP_Load_Loop
    rts

VDP_Register_Data:
    dc.b $04, $14, $30, $3C, $07, $6C, $00, $00
    dc.b $00, $00, $FF, $00, $81, $37, $00, $02
    dc.b $01, $00, $00, $00, $00, $00, $00, $00
    even

; -----------------------------------------------------------------------------
; 2. CLEAR ALL 64KB ($0000-$FFFF) OF VIDEO RAM
; -----------------------------------------------------------------------------
Clear_VRAM:
    move.l  #$8F02C000, $00C00004   ; Set VDP Auto-Increment = 2 bytes
    move.l  #$40000000, $00C00004   ; Set VDP write destination to VRAM $0000
    move.w  #$7FFF, d0              ; 32,768 words (64KB)
    moveq   #0, d1

.VRAM_Clear_Loop:
    move.w  d1, $00C00000
    dbra    d0, .VRAM_Clear_Loop
    rts

; -----------------------------------------------------------------------------
; 3. PRINT NULL-TERMINATED ASCII STRING TO VRAM NAMETABLE
; Inputs: a0 = pointer to null-terminated string, d0.l = VRAM offset command bits
; -----------------------------------------------------------------------------
Print_ASCII_String:
    move.l  #$40000000, d1
    or.l    d0, d1
    move.l  d1, $00C00004

.Print_Character_Loop:
    move.b  (a0)+, d2
    beq.s   .Print_Done
    ext.w   d2
    andi.w  #$00FF, d2
    sub.w   #$0020, d2
    add.w   #$0001, d2
    move.w  d2, $00C00000
    bra.s   .Print_Character_Loop

.Print_Done:
    rts

; -----------------------------------------------------------------------------
; 4. HARDWARE CONTROLLER PORT 1 MULTIPLEXED POLLING
; Output: d0.b = active-high button states (%SACBRLDU)
; -----------------------------------------------------------------------------
Poll_Controller_1:
    move.b  #$00, $00A10003         ; Select line LOW (Start, A)
    nop
    nop
    move.b  $00A10003, d1
    andi.b  #$30, d1
    lsl.b   #$02, d1

    move.b  #$40, $00A10003         ; Select line HIGH (C, B, Right, Left, Down, Up)
    nop
    nop
    move.b  $00A10003, d2
    andi.b  #$3F, d2

    or.b    d2, d1
    not.b   d1
    move.b  d1, d0
    rts
