-- =============================================================================
-- M68K DYNAMIC BANK-SWITCH LOGGER (MAME / Mesen Lua API)
-- Captures PC, full CPU register context, and bank values on mapper writes
-- =============================================================================

local log_file = io.open("bank_trace.log", "w")
local seen_switches = {}

local WATCH_RANGES = {
    { start_addr = 0xA130F0, end_addr = 0xA130FF },
    { start_addr = 0x220000, end_addr = 0x22000F }
}

local function dump_m68k_state(pc, addr, val, size)
    local key = string.format("%06X_%06X_%04X", pc, addr, val)
    if seen_switches[key] then return end
    seen_switches[key] = true

    local regs = string.format(
        "D0=%08X D1=%08X D2=%08X D3=%08X D4=%08X D5=%08X D6=%08X D7=%08X\n" ..
        "A0=%08X A1=%08X A2=%08X A3=%08X A4=%08X A5=%08X A6=%08X A7=%08X",
        emu:get_reg("D0"), emu:get_reg("D1"), emu:get_reg("D2"), emu:get_reg("D3"),
        emu:get_reg("D4"), emu:get_reg("D5"), emu:get_reg("D6"), emu:get_reg("D7"),
        emu:get_reg("A0"), emu:get_reg("A1"), emu:get_reg("A2"), emu:get_reg("A3"),
        emu:get_reg("A4"), emu:get_reg("A5"), emu:get_reg("A6"), emu:get_reg("A7")
    )

    local entry = string.format(
        "[BANK SWITCH] PC=$%06X -> Wrote $%04X (%d-bit) to $%06X\n%s\n" ..
        "------------------------------------------------------------------------\n",
        pc, val, size * 8, addr, regs
    )

    print(entry)
    if log_file then
        log_file:write(entry)
        log_file:flush()
    end
end

for _, range in ipairs(WATCH_RANGES) do
    for addr = range.start_addr, range.end_addr, 2 do
        emu:add_watchpoint(addr, 2, "w", function()
            local pc = emu:get_reg("PC")
            local target = emu:get_watchpoint_address()
            local val = emu:read_word(target)
            dump_m68k_state(pc, target, val, 2)
        end)
    end
end

print("[DYNAMIC TRACE] Watchpoints active. Play through level transitions to log bank swaps.")
