#!/bin/bash
set -e

GHIDRA_DIR="${GHIDRA_DIR:-/opt/ghidra}"
PROJECT_DIR="./ghidra_proj"
ROM="${1:-sonic_delta_origins.bin}"

# 1. Capture live bank switches from BlastEm
python3 collect_trace.py "$ROM"

# 2. Import 40Mbit ROM headless, create overlays, apply trace refs, and export vasm .asm
mkdir -p "$PROJECT_DIR"
"$GHIDRA_DIR/support/analyzeHeadless" "$PROJECT_DIR" SonicDeltaProj \
    -import "$ROM" \
    -processor "68000:BE:32:default" \
    -scriptPath "$(pwd)" \
    -postScript ghidra_auto_bank.py \
    -deleteProject
