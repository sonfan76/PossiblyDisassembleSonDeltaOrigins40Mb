#!/bin/bash
# =============================================================================
# EXTRADITION UTILITY PIPE FOR 40MBIT (5MB) BANKED CONSOLE BINARIES
# Splits unified bank images into individual 512KB raw binary slices
# =============================================================================

TARGET_ROM="${1:-sonic_delta_origins.bin}"
OUTPUT_DIR="./extracted_commons_chunks"
CHUNK_SIZE_BYTES=524288  # Exact byte count for a 512KB hardware memory bank page

mkdir -p "$OUTPUT_DIR"

echo "[PROCESS] Commencing extraction protocol on binary container: $TARGET_ROM"

for bank_index in {00..09}
do
    skip_blocks=$((10#$bank_index))
    echo "  -> Slicing isolated chunk layer $bank_index at offset $((skip_blocks * CHUNK_SIZE_BYTES)) bytes..."
    dd if="$TARGET_ROM" \
       of="$OUTPUT_DIR/commons_chunk_$bank_index.bin" \
       bs="$CHUNK_SIZE_BYTES" \
       count=1 \
       skip="$skip_blocks" \
       status=none
done

echo "[SUCCESS] Extraction complete. Chunks stored in $OUTPUT_DIR."
