#!/usr/bin/env python3
import os
import subprocess
from format_for_vasm import process_bank_file

os.makedirs("test_sandbox", exist_ok=True)
asm_path = "test_sandbox/BANK_00.asm"

sample_ghidra_asm = """\torg\t$000000

loc_000000:\tdc.l\t$00FFFE00, $00000200
dat_000008:\tdc.b\t$53, $45, $47, $41, $20, $4D, $45, $47, $41, $20, $44, $52, $49, $56, $45, $20
loc_000200:\tmove.b\t#$09, ($00A130FF).l
loc_000208:\tlea\t($00021A,PC), A0
loc_00020C:\tmove.l\t(0x04,A0), D0
loc_000210:\tbeq.s\t$000218
loc_000212:\tjsr\t($00380010).l
loc_000218:\trts
dat_00021A:\tdc.b\t$12, $34, $56, $78, $9A, $BC, $DE, $F0
"""

with open(asm_path, "w") as f:
    f.write(sample_ghidra_asm)

print("--- BEFORE SYMBOLIC FORMATTER ---")
print(open(asm_path).read())

process_bank_file(asm_path)

print("--- AFTER SYMBOLIC FORMATTER ---")
print(open(asm_path).read())

try:
    res = subprocess.run(
        ["vasmm68k_mot", "-Fbin", "-m68000", "-no-opt", "-spaces", "-o", "test_sandbox/BANK_00.bin", asm_path],
        capture_output=True, text=True
    )
    if res.returncode == 0:
        size = os.path.getsize("test_sandbox/BANK_00.bin")
        print(f"[VASM PASS] Compiled cleanly! Output binary size: {size} bytes.")
    else:
        print(f"[VASM ERROR]\n{res.stderr}")
except FileNotFoundError:
    print("[INFO] Formatter passed! Install 'vasmm68k_mot' in PATH to execute the binary compile step.")
