#!/usr/bin/env python3
import re
import argparse
from pathlib import Path

SONIC_MACROS_INC = """writeVRAM macro addr
    move.l  #(($40000000|((\\addr)&$3FFF)<<16)|((\\addr)>>14)),(VDP_CTRL).l
    endm

writeCRAM macro addr
    move.l  #(($C0000000|((\\addr)&$3FFF)<<16)|((\\addr)>>14)),(VDP_CTRL).l
    endm

writeVSRAM macro addr
    move.l  #(($40000010|((\\addr)&$3FFF)<<16)|((\\addr)>>14)),(VDP_CTRL).l
    endm

setVDPReg macro reg,val
    move.w  #((($80|(\\reg))<<8)|(\\val)),(VDP_CTRL).l
    endm

stopZ80 macro
    move.w  #$0100,(Z80_BUSREQ).l
    endm

startZ80 macro
    move.w  #$0000,(Z80_BUSREQ).l
    endm
"""

VDP_LONG_RE = re.compile(r"^(\s*)move\.l\s+#\$([0-9A-Fa-f]{8})\s*,\s*\(VDP_CTRL\)\.l\b(.*)$")
VDP_REG_RE = re.compile(r"^(\s*)move\.w\s+#\$8([0-9A-Fa-f])([0-9A-Fa-f]{2})\s*,\s*\(VDP_CTRL\)\.l\b(.*)$")
Z80_STOP_RE = re.compile(r"^(\s*)move\.w\s+#\$(?:0100|100)\s*,\s*\(Z80_BUSREQ\)\.l\b(.*)$")
Z80_START_RE = re.compile(r"^(\s*)move\.w\s+#\$(?:0000|0)\s*,\s*\(Z80_BUSREQ\)\.l\b(.*)$")

def strip_comma_spaces(line: str) -> str:
    if line.lstrip().startswith((";", "*")):
        return line
    out = []
    in_quote = None
    i = 0
    n = len(line)
    while i < n:
        ch = line[i]
        if in_quote:
            out.append(ch)
            if ch == in_quote:
                in_quote = None
            i += 1
            continue
        if ch in ('"', "'"):
            in_quote = ch
            out.append(ch)
            i += 1
            continue
        if ch == ";":
            out.append(line[i:])
            break
        if ch == ",":
            while out and out[-1] in (" ", "\t"):
                out.pop()
            out.append(",")
            i += 1
            while i < n and line[i] in (" ", "\t"):
                i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)

def decode_vdp_cmd_long(cmd_val):
    cd = ((cmd_val >> 30) & 0x03) | (((cmd_val >> 4) & 0x0F) << 2)
    addr = ((cmd_val >> 16) & 0x3FFF) | ((cmd_val & 0x0003) << 14)
    if (cmd_val & 0x0080) != 0:
        return None
    if cd == 0x01:
        return ("writeVRAM", addr)
    if cd == 0x03:
        return ("writeCRAM", addr)
    if cd == 0x05:
        return ("writeVSRAM", addr)
    return None

def beautify_line(line):
    m = VDP_LONG_RE.match(line)
    if m:
        indent, hex_cmd, trailing = m.groups()
        decoded = decode_vdp_cmd_long(int(hex_cmd, 16))
        if decoded:
            return strip_comma_spaces(f"{indent}{decoded[0]} ${decoded[1]:04X}{trailing}"), True
    m = VDP_REG_RE.match(line)
    if m:
        indent, reg_nib, val_hex, trailing = m.groups()
        return strip_comma_spaces(f"{indent}setVDPReg ${int(reg_nib, 16):02X},${val_hex}{trailing}"), True
    m = Z80_STOP_RE.match(line)
    if m:
        return strip_comma_spaces(f"{m.group(1)}stopZ80{m.group(2)}"), True
    m = Z80_START_RE.match(line)
    if m:
        return strip_comma_spaces(f"{m.group(1)}startZ80{m.group(2)}"), True
    cleaned = strip_comma_spaces(line)
    return cleaned, (cleaned != line)

def main():
    parser = argparse.ArgumentParser(description="Convert raw VDP/Z80 writes into Sonic community macros")
    parser.add_argument("--repo", default="sonic_delta_disasm_repo")
    args = parser.parse_args()

    repo = Path(args.repo)
    src_dir = repo / "src"
    (src_dir / "sonic_macros.inc").write_text(SONIC_MACROS_INC, encoding="utf-8")

    main_asm = repo / "main.asm"
    if main_asm.exists():
        main_txt = main_asm.read_text(encoding="utf-8")
        inc_stmt = '    include "src/sonic_macros.inc"'
        if inc_stmt not in main_txt:
            main_asm.write_text(inc_stmt + "\n" + main_txt, encoding="utf-8")

    for asm_file in src_dir.rglob("*.asm"):
        if asm_file.name == "upstream_assets.asm":
            continue
        lines = asm_file.read_text(encoding="utf-8", errors="ignore").splitlines()
        out_lines = []
        changed = False
        for line in lines:
            new_line, mod = beautify_line(line)
            out_lines.append(new_line)
            changed = changed or mod
        if changed:
            asm_file.write_text("\n".join(out_lines) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
